"""
test.py
===========
"""
from ytmedia import download_mp4

download_mp4("https://www.youtube.com/watch?v=EiiOYwqk3A0&list=RDEiiOYwqk3A0&start_radio=1")